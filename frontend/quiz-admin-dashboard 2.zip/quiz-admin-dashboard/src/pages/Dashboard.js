import React, { useState, useEffect } from "react";
import {
  getQuizzes,
  createQuiz,
  updateQuiz,
  deleteQuiz,
} from "../services/quizService";
import {
  getQuestionsByQuiz,
  createQuestion,
  updateQuestion,
} from "../services/questionService";
import {
  getAnswersByQuestion,
  createAnswer,
  updateAnswer,
} from "../services/answerService";
import ModalQuiz from "../components/ModalQuiz";
import ModalQuestion from "../components/ModalQuestion";
import ModalAnswer from "../components/ModalAnswer";
import ConfirmDeleteModal from "../components/ConfirmDeleteModal";
import Quiz from "../components/Quiz";
import { FaPlus } from "react-icons/fa";

const Dashboard = () => {
  const [quizzes, setQuizzes] = useState([]);
  const [expandedQuiz, setExpandedQuiz] = useState(null);
  const [expandedQuestion, setExpandedQuestion] = useState(null);
  const [showQuizModal, setShowQuizModal] = useState(false);
  const [showQuestionModal, setShowQuestionModal] = useState(false);
  const [showAnswerModal, setShowAnswerModal] = useState(false);
  const [modalData, setModalData] = useState({});
  const [modalAction, setModalAction] = useState(""); // Để theo dõi hành động (create/edit)
  const [modalType, setModalType] = useState(""); // Theo dõi loại modal đang mở
  const [confirmDelete, setConfirmDelete] = useState({ show: false, action: null });

  // Load quizzes
  const loadQuizzes = () => {
    getQuizzes()
      .then((data) => setQuizzes(data.data.data))
      .catch((error) => console.error("Error loading quizzes:", error));
  };

  // Expand or collapse a quiz
  const handleExpandQuiz = (quizUuid) => {
    if (expandedQuiz?.uuid === quizUuid) {
      setExpandedQuiz(null);
    } else {
      getQuestionsByQuiz(quizUuid)
        .then((questions) => {
          const questionData = questions.data.data || [];
          setExpandedQuiz({ uuid: quizUuid, questions: questionData });
        })
        .catch((error) => {
          console.error("Error loading questions:", error);
          setExpandedQuiz({ uuid: quizUuid, questions: [] });
        });
    }
  };

  // Expand or collapse a question
  const handleExpandQuestion = (questionUuid) => {
    if (expandedQuestion?.uuid === questionUuid) {
      setExpandedQuestion(null);
    } else {
      getAnswersByQuestion(questionUuid)
        .then((answers) => {
          const answerData = answers.data || [];
          setExpandedQuestion({ uuid: questionUuid, answers: answerData });
        })
        .catch((error) => {
          console.error("Error loading answers:", error);
          setExpandedQuestion({ uuid: questionUuid, answers: [] });
        });
    }
  };

  // Open modals for quiz, question, or answer
  const handleOpenModal = (type, action, data = {}) => {
    setModalType(type);
    setModalAction(action);
    setModalData(data);

    if (type === "quiz") setShowQuizModal(true);
    if (type === "question") setShowQuestionModal(true);
    if (type === "answer") setShowAnswerModal(true);
  };

  // Close modals
  const handleCloseModals = () => {
    setShowQuizModal(false);
    setShowQuestionModal(false);
    setShowAnswerModal(false);
    setModalData({});
    setModalAction("");
    setModalType("");
  };

  // Save modal data (create/edit quiz, question, answer)
  const handleSaveModal = (data) => {
    if (modalType === "quiz") {
      if (modalAction === "create") {
        createQuiz(data)
          .then(() => loadQuizzes())
          .catch((error) => console.error("Error creating quiz:", error));
      } else if (modalAction === "edit") {
        updateQuiz(data.uuid, data)
          .then(() => loadQuizzes())
          .catch((error) => console.error("Error updating quiz:", error));
      }
    } else if (modalType === "question") {
      const { quiz_uuid, ...questionData } = data;

      if (modalAction === "create") {
        createQuestion({ ...questionData, quiz_uuid })
          .then(() => handleExpandQuiz(quiz_uuid))
          .catch((error) => console.error("Error creating question:", error));
      } else if (modalAction === "edit") {
        updateQuestion(data.uuid, questionData)
          .then(() => handleExpandQuiz(quiz_uuid))
          .catch((error) => console.error("Error updating question:", error));
      }
    } else if (modalType === "answer") {
      const { question_uuid, ...answerData } = data;

      if (modalAction === "create") {
        createAnswer({ ...answerData, question_uuid })
          .then(() => handleExpandQuestion(question_uuid))
          .catch((error) => console.error("Error creating answer:", error));
      } else if (modalAction === "edit") {
        updateAnswer(data.uuid, answerData)
          .then(() => handleExpandQuestion(question_uuid))
          .catch((error) => console.error("Error updating answer:", error));
      }
    }
    handleCloseModals();
  };

  // Confirm delete
  const handleConfirmDelete = (deleteFunction) => {
    setConfirmDelete({
      show: true,
      action: deleteFunction,
    });
  };

  // Delete an item
  const handleDelete = (action) => {
    if (action) {
      action()
        .then(() => loadQuizzes())
        .catch((error) => console.error("Error deleting:", error));
    }
    setConfirmDelete({ show: false, action: null });
  };

  useEffect(() => {
    loadQuizzes();
  }, []);

  return (
    <div className="container mt-5">
      <h1>Manage Quizzes</h1>
      <button
        className="btn btn-primary mb-3"
        onClick={() => handleOpenModal("quiz", "create")}
      >
        <FaPlus /> Create Quiz
      </button>
      {quizzes.map((quiz) => (
        <Quiz
          key={quiz.uuid}
          quiz={quiz}
          expandedQuiz={expandedQuiz}
          onExpand={handleExpandQuiz}
          onCreateQuestion={() =>
            handleOpenModal("question", "create", { quiz_uuid: quiz.uuid })
          }
          onEditQuiz={(quiz) => handleOpenModal("quiz", "edit", quiz)}
          onDeleteQuiz={(quizUuid) =>
            handleConfirmDelete(() =>
              deleteQuiz(quizUuid).then(() => loadQuizzes())
            )
          }
          onCreateAnswer={(questionUuid) =>
            handleOpenModal("answer", "create", { question_uuid: questionUuid })
          }
        />
      ))}
      <ModalQuiz
        show={showQuizModal}
        action={modalAction}
        quizData={modalData}
        onClose={handleCloseModals}
        onSave={handleSaveModal}
      />
      <ModalQuestion
        show={showQuestionModal}
        action={modalAction}
        questionData={modalData}
        onClose={handleCloseModals}
        onSave={handleSaveModal}
      />
      <ModalAnswer
        show={showAnswerModal}
        action={modalAction}
        answerData={modalData}
        onClose={handleCloseModals}
        onSave={handleSaveModal}
      />
      <ConfirmDeleteModal
        show={confirmDelete.show}
        onClose={() => setConfirmDelete({ show: false, action: null })}
        onConfirm={() => handleDelete(confirmDelete.action)}
      />
    </div>
  );
};

export default Dashboard;

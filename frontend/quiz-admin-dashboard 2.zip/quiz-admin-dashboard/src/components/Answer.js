import React from "react";
import { Button } from "react-bootstrap";
import { FaEdit, FaTrash } from "react-icons/fa";

const Answer = ({ answer, onEdit, onDelete }) => (
  <tr>
    <td>{answer.description}</td>
    <td>{answer.is_correct ? "Yes" : "No"}</td>
    <td>
      <Button
        variant="warning"
        size="sm"
        className="me-2"
        onClick={() => onEdit(answer)}
      >
        <FaEdit /> Edit
      </Button>
      <Button
        variant="danger"
        size="sm"
        onClick={() => onDelete(answer.uuid)}
      >
        <FaTrash /> Delete
      </Button>
    </td>
  </tr>
);

export default Answer;

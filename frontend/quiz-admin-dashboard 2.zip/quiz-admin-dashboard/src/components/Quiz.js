import React from "react";
import { FaChevronDown, FaChevronUp, FaTrash } from "react-icons/fa";

const Quiz = ({ quiz, onExpand, expandedQuiz, onDelete }) => {
  const isExpanded = expandedQuiz?.uuid === quiz.uuid;

  return (
    <div className="quiz-item">
      <div className="d-flex justify-content-between align-items-center">
        <h4>{quiz.title}</h4>
        <div>
          <button
            className="btn btn-info"
            onClick={() => onExpand(quiz.uuid)}
          >
            {isExpanded ? <FaChevronUp /> : <FaChevronDown />}
          </button>
          <button className="btn btn-danger ms-2" onClick={onDelete}>
            <FaTrash /> Delete
          </button>
        </div>
      </div>
      {isExpanded && (
        <div className="mt-3">
          <h5>Questions</h5>
          <ul>
            {expandedQuiz.questions.map((question) => (
              <li key={question.uuid}>{question.description}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Quiz;

import React from "react";
import { Button } from "react-bootstrap";
import { FaEdit, FaTrash, FaChevronDown, FaChevronUp } from "react-icons/fa";

const Question = ({ question, onEdit, onDelete, onExpand, expanded }) => (
  <>
    <tr>
      <td>{question.description}</td>
      <td>{question.type === 1 ? "Default" : "Multiple Choice"}</td>
      <td>{question.position}</td>
      <td>
        <Button
          variant="warning"
          size="sm"
          className="me-2"
          onClick={() => onEdit(question)}
        >
          <FaEdit /> Edit
        </Button>
        <Button
          variant="danger"
          size="sm"
          onClick={() => onDelete(question.uuid)}
        >
          <FaTrash /> Delete
        </Button>
        <Button
          variant="info"
          size="sm"
          onClick={() => onExpand(question.uuid)}
        >
          {expanded ? <FaChevronUp /> : <FaChevronDown />}
        </Button>
      </td>
    </tr>
  </>
);

export default Question;

package repositories

import (
	"fmt"
	"quiz-api/config"

	"github.com/gocql/gocql"
)

type ScyllaDBRepository struct {
	Session *gocql.Session
}

func NewScyllaDBRepository(scyllaDB *config.ScyllaDB) *ScyllaDBRepository {
	return &ScyllaDBRepository{Session: scyllaDB.Session}
}

func (repo *ScyllaDBRepository) InsertRecord(tableName string, data map[string]interface{}) error {
	query := fmt.Sprintf("INSERT INTO %s (%s) VALUES (%s)", tableName, keys(data), placeholders(len(data)))
	values := values(data)

	if err := repo.Session.Query(query, values...).Exec(); err != nil {
		return fmt.Errorf("failed to insert record: %w", err)
	}
	return nil
}

func (repo *ScyllaDBRepository) SelectRecords(tableName string, columns []string, conditions map[string]interface{}) ([]map[string]interface{}, error) {
	query := fmt.Sprintf("SELECT %s FROM %s WHERE %s", columnList(columns), tableName, conditionList(conditions))
	iter := repo.Session.Query(query, conditionValues(conditions)...).Iter()

	result := []map[string]interface{}{}
	for {
		row := map[string]interface{}{}
		if !iter.MapScan(row) {
			break
		}
		result = append(result, row)
	}

	if err := iter.Close(); err != nil {
		return nil, fmt.Errorf("failed to retrieve records: %w", err)
	}
	return result, nil
}

func (repo *ScyllaDBRepository) UpdateRecord(tableName string, updates map[string]interface{}, conditions map[string]interface{}) error {
	query := fmt.Sprintf("UPDATE %s SET %s WHERE %s", tableName, updateList(updates), conditionList(conditions))
	values := append(values(updates), conditionValues(conditions)...)

	if err := repo.Session.Query(query, values...).Exec(); err != nil {
		return fmt.Errorf("failed to update record: %w", err)
	}
	return nil
}

func (repo *ScyllaDBRepository) DeleteRecord(tableName string, conditions map[string]interface{}) error {
	query := fmt.Sprintf("DELETE FROM %s WHERE %s", tableName, conditionList(conditions))
	if err := repo.Session.Query(query, conditionValues(conditions)...).Exec(); err != nil {
		return fmt.Errorf("failed to delete records: %w", err)
	}
	return nil
}

// Helper functions for query building
func keys(data map[string]interface{}) string {
	keyList := []string{}
	for key := range data {
		keyList = append(keyList, key)
	}
	return join(keyList, ", ")
}

func placeholders(n int) string {
	return join(make([]string, n), "?")
}

func values(data map[string]interface{}) []interface{} {
	valList := []interface{}{}
	for _, val := range data {
		valList = append(valList, val)
	}
	return valList
}

func columnList(columns []string) string {
	return join(columns, ", ")
}

func updateList(updates map[string]interface{}) string {
	parts := []string{}
	for key := range updates {
		parts = append(parts, fmt.Sprintf("%s = ?", key))
	}
	return join(parts, ", ")
}

func conditionList(conditions map[string]interface{}) string {
	parts := []string{}
	for key := range conditions {
		parts = append(parts, fmt.Sprintf("%s = ?", key))
	}
	return join(parts, " AND ")
}

func conditionValues(conditions map[string]interface{}) []interface{} {
	valList := []interface{}{}
	for _, val := range conditions {
		valList = append(valList, val)
	}
	return valList
}

func join(items []string, delimiter string) string {
	result := ""
	for i, item := range items {
		if i > 0 {
			result += delimiter
		}
		result += item
	}
	return result
}
